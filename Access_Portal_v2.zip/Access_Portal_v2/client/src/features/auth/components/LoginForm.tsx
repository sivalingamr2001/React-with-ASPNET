﻿import { useState } from "react";
import { useForm, type Control } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { cn } from "@/lib/utils";
import { Button } from "@/shared/components/ui/button";
import { Input } from "@/shared/components/ui/input";
import { Label } from "@/shared/components/ui/label";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/shared/components/ui/form";
import { Alert, AlertDescription } from "@/shared/components/ui/alert";

const loginSchema = z.object({
  email: z
    .string()
    .min(1, "Email address is required")
    .email("Please enter a valid email address"),
  password: z
    .string()
    .min(1, "Password is required")
    .min(8, "Password must be at least 8 characters"),
  rememberMe: z.boolean().optional().default(false),
});

const JanaticsLogo = () => (
  <svg viewBox="0 0 48 48" fill="none" className="w-full h-full">
    <rect width="48" height="48" rx="12" fill="url(#logoGrad)" />
    <path d="M14 16h6v12a4 4 0 01-8 0v-2h4v2a1 1 0 002 0V16z" fill="white" opacity="0.95"
    />
    <path d="M26 16h12v4H30v3h7v4h-7v3h8v4H26V16z" fill="white" opacity="0.95" />
    <defs>
      <linearGradient id="logoGrad" x1="0" y1="0" x2="48" y2="48">
        <stop stopColor="#1d4ed8" />
        <stop offset="1" stopColor="#0ea5e9" />
      </linearGradient>
    </defs>
  </svg>
);
const EyeOpenIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);
const EyeClosedIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-
5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0
11-4.24-4.24" />
    <line x1="1" y1="1" x2="23" y2="23" />
  </svg>
);
const MailIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"
    />
    <polyline points="22,6 12,13 2,6" />
  </svg>
);
const LockIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
    <path d="M7 11V7a5 5 0 0110 0v4" />
  </svg>
);
const AlertCircleIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" />
    <line x1="12" y1="8" x2="12" y2="12" />
    <line x1="12" y1="16" x2="12.01" y2="16" />
  </svg>
);
const ShieldCheckIcon = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    <polyline points="9 12 11 14 15 10" />
  </svg>
);
const ArrowRightIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="5" y1="12" x2="19" y2="12" />
    <polyline points="12 5 19 12 12 19" />
  </svg>
);
// ─── Brand Panel
const BrandPanel = () => (
  <div className="hidden lg:flex flex-col justify-between bg-linear-to-br from-blue-950
via-blue-900 to-sky-800 p-12 relative overflow-hidden">
    <div
      className="absolute inset-0 opacity-10"
      style={{
        backgroundImage:
          "linear-gradient(rgba(255,255,255,0.12) 1px,transparent 1px),lineargradient(90deg,rgba(255,255,255,0.12) 1px,transparent 1px)",
        backgroundSize: "40px 40px",
      }}
    />
    <div className="absolute -top-32 -left-32 w-96 h-96 bg-sky-400 rounded-full opacity-10
blur-3xl pointer-events-none" />
    <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-blue-400 rounded-full
opacity-10 blur-3xl pointer-events-none" />
    {/* Brand */}
    <div className="relative z-10">
      <div className="flex items-center gap-3 mb-1">
        <div className="w-10 h-10 shrink-0"><JanaticsLogo /></div>
        <span className="text-white text-xl font-bold tracking-tight" style={{
          fontFamily:
            "'Syne',sans-serif"
        }}>
          Janatics
        </span>
      </div>
      <p className="text-sky-400 text-xs font-semibold tracking-widest uppercase pl-0.5">
        Access Portal
      </p>
    </div>
    {/* Hero copy */}
    <div className="relative z-10 space-y-8">
      <div>
        <h2 className="text-white text-4xl font-bold leading-snug mb-3" style={{
          fontFamily:
            "'Syne',sans-serif"
        }}>
          Request &amp; Track<br />
          <span className="text-sky-300">System Access</span><br />
          Effortlessly
        </h2>
        <p className="text-blue-200 text-sm leading-relaxed max-w-xs">
          Submit access requests, monitor approval status, and get notified at every stage — all
          in one secure portal.
        </p>
      </div>
      {/* Approval steps */}
      <div className="space-y-3">
        {[
          { n: "01", label: "Submit Access Request", on: true },
          { n: "02", label: "Level 1 — Manager Approval", on: true },
          { n: "03", label: "Level 2 — IT Admin Approval", on: false },
          { n: "04", label: "Access Provisioned", on: false },
        ].map(({ n, label, on }) => (
          <div key={n} className="flex items-center gap-3">
            <div
              className={cn(
                "w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0",
                on ? "bg-sky-400 text-blue-950" : "bg-white/10 text-blue-300 border borderwhite/10"
              )}
              style={{ fontFamily: "'DM Mono',monospace" }}
            >
              {n}
            </div>
            <span className={cn("text-sm", on ? "text-white font-medium" : "text-blue-400")}>
              {label}
            </span>
          </div>
        ))}
      </div>
    </div>
    {/* Security badge */}
    <div className="relative z-10 flex items-center gap-2 text-blue-400 text-xs">
      <ShieldCheckIcon />
      <span>ISO 27001 · 256-bit TLS · Zero Trust Architecture</span>
    </div>
  </div>
);
// ─── Login Form
// If you have the schema nearby:
type LoginFormValues = z.infer<typeof loginSchema>;

interface LoginFormProps {
  // Change this to match the full schema including rememberMe
  onLogin: (data: LoginFormValues) => void | Promise<void>;
}


export default function LoginForm({ onLogin }: LoginFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [serverError, setServerError] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);
  const form = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "", rememberMe: false },
  });
  const { formState: { isSubmitting, errors } } = form;
  const onSubmit = async (data: LoginFormValues) => {
    setServerError("");
    try {
      await new Promise((res) => setTimeout(res, 1400));
      if (data.password === "wrongpass") {
        setServerError("Invalid email or password. Please try again.");
        return;
      }
      setIsSuccess(true);
      onLogin?.(data);
    } catch {
      setServerError("Something went wrong. Please try again later.");
    }
  };
  return (
    <>
      <div className=" flex items-center justify-center p-4">
        <div className="w-full max-w-4xl overflow-hidden rounded-2xl shadow-2xl shadowslate-200/70 grid lg:grid-cols-[1.1fr_1fr] border border-slate-100 bg-white">
          {/* Left — Brand */}
          <BrandPanel />
          {/* Right — Form */}
          <div className="flex flex-col justify-center px-8 py-12 sm:px-12">
            {isSuccess ? (
              /* Success */
              <div className="flex flex-col items-center text-center gap-5 jn-pop">
                <div className="w-20 h-20 rounded-full  border-2 border-emerald100 flex items-center justify-center">
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#10b981"
                    strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
                    <polyline points="22 4 12 14.01 9 11.01" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-slate-900 text-xl font-bold mb-1" style={{
                    fontFamily:
                      "'Syne',sans-serif"
                  }}>
                    Welcome back!
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    Authentication successful.<br />Redirecting to your dashboard…
                  </p>
                </div>
                <div className="flex gap-2 mt-1">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className={cn("w-2 h-2 rounded-full bg-blue-600 jn-dot", `jn-dot${i + 1}`)}
                    />
                  ))}
                </div>
              </div>
            ) : (
              <>
                {/* Mobile logo */}
                <div className="flex lg:hidden items-center gap-2.5 mb-8">
                  <div className="w-9 h-9 shrink-0"><JanaticsLogo /></div>
                  <div>
                    <p className="font-bold text-slate-900 text-sm leading-none" style={{
                      fontFamily: "'Syne',sans-serif"
                    }}>Janatics</p>
                    <p className="text-xs text-slate-400 tracking-widest uppercase mt-0.5">Access
                      Portal</p>
                  </div>
                </div>
                {/* Heading */}
                <div className="mb-8 jn-a jn-a1">
                  <p className="text-xs font-semibold tracking-widest uppercase text-blue-600 mb-2"
                    style={{ fontFamily: "'DM Mono',monospace" }}>
                    Employee Portal
                  </p>
                  <h1 className="text-slate-900 text-[2rem] font-bold leading-tight" style={{
                    fontFamily: "'Syne',sans-serif"
                  }}>
                    Sign in
                  </h1>
                  <p className="text-slate-400 text-sm mt-1.5">
                    Enter your credentials to continue
                  </p>
                </div>
                {/* Server error */}
                {serverError && (
                  <Alert className="mb-5 border-red-200 bg-red-50 rounded-xl jn-a">
                    <div className="flex items-center gap-2 text-red-600">
                      <AlertCircleIcon />
                      <AlertDescription className="text-sm font-medium text-red-600">
                        {serverError}
                      </AlertDescription>
                    </div>
                  </Alert>
                )}
                {/* Form fields */}
                <Form {...form}>
                  <div className="space-y-5">
                    {/* Email */}
                    <div className="jn-a jn-a2">
                      <FormField
                        control={form.control as Control<any>}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <Label className="block text-xs font-semibold text-slate-500 uppercase tracking-widest mb-2">
                              Email Address
                            </Label>
                            <FormControl>
                              <div className="relative group">
                                <span className={cn(
                                  "absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none transitioncolors",
                                  errors.email ? "text-red-400" : "text-slate-400 group-focus-within:text-blue500"
                                )}>
                                  <MailIcon />
                                </span>
                                <Input
                                  {...field}
                                  type="email"
                                  placeholder="you@janatics.com"
                                  autoComplete="email"
                                  className={cn(
                                    "h-11 pl-10 rounded-xl text-sm bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-300 transition-all",
                                    "focus-visible:ring-2 focus-visible:ring-blue-500/25 focus-visible:borderblue-500 focus-visible:bg-white",
                                    errors.email && "border-red-300 bg-red-50/40 focus-visible:ring-red400/25 focus-visible:border-red-400"
                                  )}
                                />
                              </div>
                            </FormControl>
                            <FormMessage className="text-xs text-red-500 mt-1.5 font-medium" />
                          </FormItem>
                        )}
                      />
                    </div>
                    {/* Password */}
                    <div className="jn-a jn-a3">
                      <FormField
                        control={form.control as Control<any>}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <div className="flex items-center justify-between mb-2">
                              <Label className="text-xs font-semibold text-slate-500 uppercase tracking-widest">
                                Password
                              </Label>
                              <button
                                type="button"
                                className="text-xs text-blue-600 hover:text-blue-700 font-semibold transition-colors focus:outline-none"
                              >
                                Forgot password?
                              </button>
                            </div>
                            <FormControl>
                              <div className="relative group">
                                <span className={cn(
                                  "absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none transitioncolors",
                                  errors.password ? "text-red-400" : "text-slate-400 group-focus-within:textblue-500"
                                )}>
                                  <LockIcon />
                                </span>
                                <Input
                                  {...field}
                                  type={showPassword ? "text" : "password"}
                                  placeholder="Min. 8 characters"
                                  autoComplete="current-password"
                                  className={cn(
                                    "h-11 pl-10 pr-11 rounded-xl text-sm bg-slate-50 border-slate-200 textslate-900 placeholder:text-slate-300 transition-all",
                                    "focus-visible:ring-2 focus-visible:ring-blue-500/25 focus-visible:borderblue-500 focus-visible:bg-white",
                                    errors.password && "border-red-300 bg-red-50/40 focus-visible:ring-red400/25 focus-visible:border-red-400"
                                  )}
                                />
                                <button
                                  type="button"
                                  onClick={() => setShowPassword((v) => !v)}
                                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
                                  aria-label={showPassword ? "Hide password" : "Show password"}
                                >
                                  {showPassword ? <EyeClosedIcon /> : <EyeOpenIcon />}
                                </button>
                              </div>
                            </FormControl>
                            <FormMessage className="text-xs text-red-500 mt-1.5 font-medium" />
                          </FormItem>
                        )}
                      />
                    </div>
                    {/* CTA */}
                    <div className="pt-1 jn-a jn-a4">
                      <Button
                        type="button"
                        disabled={isSubmitting}
                        onClick={form.handleSubmit(onSubmit)}
                        className={cn(
                          "w-full h-11 rounded-xl text-sm font-semibold tracking-wide border-0",
                          "bg-linear-to-r from-blue-700 via-blue-600 to-sky-500",
                          "hover:from-blue-600 hover:via-blue-500 hover:to-sky-400",
                          "shadow-lg shadow-blue-600/20 hover:shadow-blue-600/35",
                          "text-white transition-all duration-200",
                          "disabled:opacity-60 disabled:cursor-not-allowed disabled:shadow-none"
                        )}
                      >
                        {isSubmitting ? (
                          <span className="flex items-center gap-2.5">
                            <svg className="jn-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3"
                                strokeOpacity=".25" />
                              <path d="M22 12a10 10 0 00-10-10" stroke="currentColor" strokeWidth="3"
                                strokeLinecap="round" />
                            </svg>
                            Authenticating…
                          </span>
                        ) : (
                          <span className="flex items-center gap-2">
                            Sign in to Portal
                            <ArrowRightIcon />
                          </span>
                        )}
                      </Button>
                    </div>
                  </div>
                </Form>
                {/* Footer */}
                <div className="mt-8 pt-6 border-t border-slate-100 jn-a jn-a5">
                  <div className="flex items-center justify-center gap-4 text-xs text-slate-400">
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 jn-dot jn-dot1" />
                      All systems operational
                    </span>
                    <span className="text-slate-200 select-none">|</span>
                    <span className="flex items-center gap-1">
                      <ShieldCheckIcon />
                      Secure connection
                    </span>
                  </div>
                  <p className="text-center text-xs text-slate-300 mt-3">
                    © {new Date().getFullYear()} Janatics India Ltd. · Internal use only.
                  </p>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
﻿export const UserTable = () => null;

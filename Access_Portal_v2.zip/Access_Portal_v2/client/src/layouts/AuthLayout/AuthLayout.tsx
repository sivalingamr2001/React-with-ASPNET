﻿import { Outlet } from "react-router-dom";

export const AuthLayout = () => (
  <div className="min-h-screen bg-slate-50 px-4 py-10 flex items-center justify-center">
    <div className="w-full max-w-6xl">
      <Outlet />
    </div>
  </div>
);

﻿import { useEffect, useRef } from "react";
import { Outlet, useLocation } from "react-router-dom";
import gsap from "gsap";
import { Header } from "./Header";
import { Sidebar } from "./Sidebar";

export const AppLayout = () => {
  const mainRef = useRef<HTMLDivElement>(null);
  const location = useLocation();

  useEffect(() => {
    // 1. Initial Page Load Animation
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "expo.out" } });

      tl.from(".header-container", { y: -100, opacity: 0, duration: 1.2 })
        .from(".sidebar-container", { x: -50, opacity: 0, duration: 1 }, "-=0.8")
        .from(".main-content", { y: 20, opacity: 0, duration: 0.8 }, "-=0.6");
    });

    return () => ctx.revert();
  }, []);

  useEffect(() => {
    gsap.fromTo(
      ".route-wrapper",
      { opacity: 0, y: 10 },
      { opacity: 1, y: 0, duration: 0.4, ease: "power2.out" }
    );
  }, [location.pathname]);

  return (
    <div className="relative min-h-screen overflow-hidden bg-background text-foreground selection:bg-primary/20">
      <div className="fixed inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent" />

      <div className="header-container sticky top-0 z-50">
        <Header />
      </div>

      <div className="flex min-h-[calc(100vh-64px)] flex-col lg:flex-row">
        <aside className="sidebar-container w-full lg:w-72">
          <Sidebar />
        </aside>

        <main
          ref={mainRef}
          className="main-content"
        >

          <div className="route-wrapper">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};
